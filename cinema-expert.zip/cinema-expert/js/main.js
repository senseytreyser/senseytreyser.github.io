﻿window.onload = function(){
    carouselClick();
}